from flask import Flask, request, jsonify
import joblib
import pandas as pd

app = Flask(__name__)

# Load the saved Parkinson's model
try:
    Heart_model = joblib.load(r'Heart_Disease_Predictor\heart_model.pkl')
except FileNotFoundError:
    print("Model file not found. Please ensure the path is correct.")
    exit() 

# Endpoint for predicting Parkinson's disease
@app.route('/predict_heart', methods=['POST'])
def predict_heart():
    try:
        data = request.get_json(force=True)                   
         
        #validate sex/gender input
        if data['sex'] not in ['male','female']:
            return jsonify({'error':'Invalid input for gender.Must be "male" or "female".'}),400
        
        # Convert the input data to a DataFrame
        try:
           input_features = pd.DataFrame([{
                'age': data['age'],	
                'sex': 1 if data['sex'] == 'male' else 0,                    
                'cp': data['cp'],	
                'trestbps': data['trestbps'],	
                'chol': data['chol'],
                'fbs': data['fbs'],	
                'restecg': data['restecg'],	
                'thalach': data['thalach'],	
                'exang': data['exang'],	
                'oldpeak': data['oldpeak'],	
                'slope': data['slope'],	
                'ca': data['ca'],	
                'thal':	data['thal'],    
            }])
    
        except ValueError as ve:
            return jsonify({'error': f'Invalid input type: {str(ve)}'}), 400
        
        # Predict using the loaded model
        prediction = Heart_model.predict(input_features)

        # Result: 1 for Parkinson's disease, 0 for no disease
        result = "Heart Disease" if prediction[0] == 1 else "No Heart Diease"

        # Send the result back as JSON
        return jsonify({'prediction': result})

    except Exception as e:
        return jsonify({'error': 'An error occurred: ' + str(e)}), 500
    
if __name__ == '__main__':
    app.run(debug=True)
