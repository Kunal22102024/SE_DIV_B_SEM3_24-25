from flask import Flask, request, jsonify
import joblib
import pandas as pd

app = Flask(__name__)

# Load the saved Parkinson's model
try:
    parkinsons_model = joblib.load(r'Parkinsons_Disease\parkinsons_model.pkl')
except FileNotFoundError:
    print("Model file not found. Please ensure the path is correct.")
    exit()

# Endpoint for predicting Parkinson's disease
@app.route('/predict_parkinsons', methods=['POST'])
def predict_parkinsons():
    
    try:
        
        data = request.get_json(force=True)
        
        try:
             # Convert the input data to a DataFrame
            input_features = pd.DataFrame([{
                'MDVP:Fo(Hz)': data['MDVP:Fo(Hz)'],
                'MDVP:Fhi(Hz)': data['MDVP:Fhi(Hz)'],
                'MDVP:Flo(Hz)': data['MDVP:Flo(Hz)'],
                'MDVP:Jitter(%)': data['MDVP:Jitter(%)'],
                'MDVP:Jitter(Abs)': data['MDVP:Jitter(Abs)'],
                'MDVP:RAP': data['MDVP:RAP'],
                'MDVP:PPQ': data['MDVP:PPQ'],
                'Jitter:DDP': data['Jitter:DDP'],
                'MDVP:Shimmer': data['MDVP:Shimmer'],
                'MDVP:Shimmer(dB)': data['MDVP:Shimmer(dB)'],
                'Shimmer:APQ3': data['Shimmer:APQ3'],
                'Shimmer:APQ5': data['Shimmer:APQ5'],
                'MDVP:APQ': data['MDVP:APQ'],
                'Shimmer:DDA': data['Shimmer:DDA'],
                'NHR': data['NHR'],
                'HNR': data['HNR'],
                'RPDE': data['RPDE'],
                'DFA': data['DFA'],
                'spread1': data['spread1'],
                'spread2': data['spread2'],
                'D2': data['D2'],
                'PPE': data['PPE'],
            }])
        
        except ValueError as ve:
            return jsonify({'error': f'Invalid input type: {str(ve)}'}), 400

         # Predict using the loaded model
        prediction = parkinsons_model.predict(input_features)

        # Result: 1 for Parkinson's disease, 0 for no disease
        result = "Parkinson's Disease" if prediction[0] == 1 else "No Parkinson's Disease"

        # Send the result back as JSON
        return jsonify({'prediction': result})

    except Exception as e:
        return jsonify({'error': 'An error occurred: ' + str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
