from flask import Flask, request, jsonify
import joblib
import pandas as pd

app = Flask(__name__)

# Load your trained SVM model
try:
    diabetes_model = joblib.load(r'Diabetes\diabetes_model.pkl')
except FileNotFoundError:
    print("Model file not found. Please ensure the path is correct.")
    exit()

# Endpoint for predicting Parkinson's disease
@app.route('/predict_diabetes', methods=['POST'])
def predict():
    try:
        # Get JSON data from the request
        data = request.get_json(force=True)

        # Validate input data
        required_fields = ['gender','age', 'hypertension', 'heart_disease', 'smoking_history',
                           'bmi', 'HbA1c_level', 'blood_glucose_level']
        
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing field: {field}'}), 400

        # Validate heart disease input
        if data['heart_disease'] not in ['yes', 'no']:
            return jsonify({'error': 'Invalid input for heart disease. Must be "yes" or "no".'}), 400
        
        #validate hypertension input
        if data['hypertension'] not in ['yes', 'no']:
            return jsonify({'error': 'Invalid input for hypertension. Must be "yes" or "no".'}), 400
        
        #validate gender input
        if data['gender'] not in ['male','female']:
            return jsonify({'error':'Invalid input for gender.Must be "male" or "female".'}),400

        # Validate smoking history input and map to numeric values
        smoking_mapping = {
            'no': 0,
            'never': -1,
            'no info': -2,
            'not current': 1,
            'current': 2,
            'former': 3
        }
        
        if data['smoking_history'] not in smoking_mapping:
            return jsonify({'error': 'Invalid input for smoking history. Must be one of: "no", "never", "no info", "not current", "current", "former".'}), 400

        # Validate other inputs and convert to appropriate types
        try:
            input_features = {
                'age': float(data['age']),
                'hypertension': 1 if data['hypertension'] == 'yes' else 0,
                'heart_disease': 1 if data['heart_disease'] == 'yes' else 0,
                'bmi': float(data['bmi']),
                'HbA1c_level': float(data['HbA1c_level']),
                'blood_glucose_level': float(data['blood_glucose_level'])
            }
        except ValueError as ve:
            return jsonify({'error': f'Invalid input type: {str(ve)}'}), 400

        # Create a DataFrame from the validated input data
        input_df = pd.DataFrame([input_features])

        # Make prediction
        prediction = diabetes_model.predict(input_df)
        result = "Diabetes" if prediction[0] == 1 else "No Diabetes."
        
        return jsonify({'prediction': result})

    except Exception as e:
        return jsonify({'error': 'An error occurred: ' + str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)  # Specify port if needed
